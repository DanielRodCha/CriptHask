Este proyecto contiene los códigos correspondientes al TFG.

Para instalarlo

+ Si no se tiene, instalar stack. Las instrucciones para instalarlo están en
  http://docs.haskellstack.org/en/stable/README

+ Ejecutar
     stack build
     
