#!/usr/bin/env runhaskell

import qualified Distribution.Simple

main = Distribution.Simple.defaultMain
